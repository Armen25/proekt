
<?php
require '../Db.php';
$user = [];
foreach ($_POST as $key => $value){
    $keyUser = strval(htmlspecialchars($key));
    $valueUser = strval(htmlspecialchars($value));
    $user[$keyUser] = $valueUser;
}
$db = new Db();
if (!empty($user['login'])){
    $response = $db->getLogin($user['login']);
    if ($response['status']) {
        if (password_verify($user['password'], $response['data']['password'])) {
            echo 'вы успешно вошли, '.$response['data']['login'];
        } else {
            die('Не верный логин или пароль');
        }
    } else {
        echo 'Не получилось войти.'.$response['errorInfo'];
    }
} else {
    die('Не верный логин или пароль');
}