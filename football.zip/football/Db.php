<?php
/**
 * class to interact with the database
 */
class Db
{
    public $connect; // connect to Db
    public $response = [
        'status' => false , // boolean [true , false]
        'data' => [] , // array
        'errorInfo' => '', // error Info

    ];
     
    public function __construct(){
        $this->connect = new PDO('mysql:host=localhost;dbname=football', 'root', '');
    }
    //     /**
    //     *  authorization for already exists user
    //     *  @param string $login login of user
    //     *  @param string $password passsword of user
    //     *  @return array ответ от базы данных (статус , информация , код ошибки)
    //     */
    // public function authorization($login , $password){
    //     $sth = $this->connect->prepare("SELECT * FROM user WHERE login = ? AND password = ?");
    //     $sth->execute(Array($login, $password));
    //     $data = $sth->fetch();
    //     if (empty($data)) {
    //         $this->response['status'] = false;
    //         $this->response['errorInfo'] = 'user not found';
    //     } else {
    //         $this->response['status'] = true;
    //         $this->response['data'] = $data;
    //     } 
    //     return $this->response;
    // } 
        /**
        *  registration of new user
        *  @param string $login login of user
        *  @param string $password passsword of user
        *  @param string $email email of user
        *  @param string $fio fio of user
        *  @param string $contacts contacts of user
        *  @return array ответ от базы данных (статус , информация , код ошибки)
        */
    public function registration($login , $password, $email, $fio, $contacts){
        if (!$this->getLogin($login)['status']) {
            $this->response['status'] = false;
            $this->response['errorInfo'] = 'user already exists';
        } else {
            $sth = $this->connect->prepare("INSERT INTO user (login, password, email, fio, contacts) VALUES (?, ?, ?, ?, ?)");
            $status = $sth->execute(Array($login, $password, $email, $fio, $contacts));
            if (!$status) {
                $this->response['status'] = false;
                $this->response['errorInfo'] = 'error of insert into database';
            } else {
                $this->response['status'] = true;
            } 
        }
        return $this->response;
    } 
        /**
        *  check user with this login
        *  @param string $login login of user
        *  @return (array||false) ответ от базы данных data если пользователь зарегестрирован с таким login, false если пользователь не зарегестрирован
        */
    public function getLogin($login){
        $sth = $this->connect->prepare("SELECT * FROM user WHERE login = ?");
        if ($sth->execute(Array($login))) {
            $data = $sth->fetch();
            $this->response['status'] = true;
            $this->response['data'] = $data;
        } else {
            $this->response['status'] = false;
            $this->response['errorInfo'] = 'error of select from database';
        }
        return $this->response;
    }
}